from collections.abc import Iterable

from regent.application.p1_ports import EvidenceSourceRequest, EvidenceSourceSnapshot


class InMemoryEvidenceSourceConnector:
    """Deterministic connector for orchestration tests; performs no network side effects."""

    def __init__(self, snapshots: Iterable[EvidenceSourceSnapshot]) -> None:
        self._snapshots = tuple(snapshots)
        self.requests: list[EvidenceSourceRequest] = []

    async def fetch(self, request: EvidenceSourceRequest) -> list[EvidenceSourceSnapshot]:
        self.requests.append(request)
        return list(self._snapshots)
