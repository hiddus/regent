from regent.application.p1_ports import (
    DeploymentRequest,
    DeploymentResult,
)


class InMemoryDeploymentProvider:
    def __init__(self) -> None:
        self.results: dict[str, DeploymentResult] = {}
        self.requests: list[DeploymentRequest] = []

    async def deploy(self, request: DeploymentRequest) -> DeploymentResult:
        self.requests.append(request)
        existing = self.results.get(request.idempotency_key)
        if existing is not None:
            return existing
        result = DeploymentResult(
            external_request_id=request.idempotency_key,
            status="SUCCEEDED",
            endpoint=f"https://preview.invalid/{request.idempotency_key}",
            evidence={"provider": "in-memory"},
        )
        self.results[request.idempotency_key] = result
        return result

    async def query(self, external_request_id: str) -> DeploymentResult:
        try:
            return self.results[external_request_id]
        except KeyError as exc:
            raise LookupError("unknown deployment") from exc

    async def rollback(self, external_request_id: str, correlation_id: str) -> DeploymentResult:
        if external_request_id not in self.results:
            raise LookupError("unknown deployment")
        return DeploymentResult(
            external_request_id=external_request_id,
            status="SUCCEEDED",
            endpoint=f"https://preview.invalid/{external_request_id}",
            evidence={
                "provider": "in-memory",
                "rolled_back": True,
                "correlation_id": correlation_id,
            },
        )
