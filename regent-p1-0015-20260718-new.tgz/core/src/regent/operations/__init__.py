"""Operational verification commands."""
