import uuid
from pathlib import Path
from typing import Annotated, Any

from fastapi import APIRouter, Depends, Request, status
from pydantic import BaseModel, Field

from regent.application.build_service import (
    BuildService,
    RequestAppBuild,
    RequestDependencyResolution,
)
from regent.application.generation_service import (
    CreateGenerationPlan,
    GenerationService,
    RequestGenerationRun,
)
from regent.application.p1_contracts import GenerationPlanContract
from regent.application.permit_service import PermitService
from regent.config import get_settings
from regent.infrastructure.artifact_store import FileArtifactStore
from regent.infrastructure.code_generator import ArtifactBackedCodeGenerator, ArtifactUriResolver
from regent.infrastructure.sandbox import DockerDependencyMaterializer, DockerSandboxDriver
from regent.infrastructure.workspace_writer import WorkspaceWriter
from regent.model.factory import build_model_provider

router = APIRouter(tags=["app-delivery"])


class CreateGenerationPlanBody(BaseModel):
    requirement_revision_id: uuid.UUID
    contract: GenerationPlanContract
    architecture_summary: str = Field(min_length=1)
    component_plan: list[dict[str, Any]] = Field(default_factory=list)
    actor: str = Field(min_length=1)
    correlation_id: str = Field(min_length=1)


class RequestGenerationRunBody(BaseModel):
    idempotency_key: str = Field(min_length=1, max_length=255)
    correlation_id: str = Field(min_length=1, max_length=255)


class GenerationPlanResponse(BaseModel):
    id: uuid.UUID
    status: str
    version: int
    input_digest: str


class GenerationRunResponse(BaseModel):
    id: uuid.UUID
    plan_id: uuid.UUID
    attempt: int
    status: str
    version: int
    correlation_id: str
    model_ref: str | None
    failure_code: str | None


def service(request: Request) -> GenerationService:
    settings = get_settings()
    artifacts = FileArtifactStore(Path(settings.artifact_root))
    return GenerationService(
        request.app.state.sessions,
        ArtifactBackedCodeGenerator(build_model_provider(settings), artifacts),
        WorkspaceWriter(Path(settings.workspace_root), ArtifactUriResolver(artifacts.root)),
    )


ServiceDep = Annotated[GenerationService, Depends(service)]


@router.post(
    "/v1/resolution-plans/{resolution_plan_id}/generation-plans",
    response_model=GenerationPlanResponse,
    status_code=status.HTTP_201_CREATED,
)
async def create_generation_plan(
    resolution_plan_id: uuid.UUID,
    payload: CreateGenerationPlanBody,
    generation: ServiceDep,
) -> GenerationPlanResponse:
    model = await generation.create_plan(
        CreateGenerationPlan(
            capability_resolution_plan_id=resolution_plan_id,
            **payload.model_dump(),
        )
    )
    return GenerationPlanResponse(
        id=model.id,
        status=model.status,
        version=model.version,
        input_digest=model.input_digest,
    )


@router.post(
    "/v1/generation-plans/{plan_id}/runs",
    response_model=GenerationRunResponse,
    status_code=status.HTTP_202_ACCEPTED,
)
async def request_generation_run(
    plan_id: uuid.UUID,
    payload: RequestGenerationRunBody,
    generation: ServiceDep,
) -> GenerationRunResponse:
    model = await generation.request_run(
        RequestGenerationRun(plan_id=plan_id, **payload.model_dump())
    )
    return run_response(model)


@router.get("/v1/generation-runs/{run_id}", response_model=GenerationRunResponse)
async def get_generation_run(run_id: uuid.UUID, generation: ServiceDep) -> GenerationRunResponse:
    return run_response(await generation.get_run(run_id))


def run_response(model: Any) -> GenerationRunResponse:
    return GenerationRunResponse(
        id=model.id,
        plan_id=model.plan_id,
        attempt=model.attempt,
        status=model.status,
        version=model.version,
        correlation_id=model.correlation_id,
        model_ref=model.model_ref,
        failure_code=model.failure_code,
    )


class RequestDependenciesBody(BaseModel):
    dependency_intents: list[dict[str, Any]] = Field(default_factory=list)
    idempotency_key: str = Field(min_length=1, max_length=255)
    correlation_id: str = Field(min_length=1, max_length=255)


class RequestBuildBody(BaseModel):
    dependency_resolution_id: uuid.UUID
    idempotency_key: str = Field(min_length=1, max_length=255)
    correlation_id: str = Field(min_length=1, max_length=255)


class DependencyResolutionResponse(BaseModel):
    id: uuid.UUID
    workspace_snapshot_id: uuid.UUID
    status: str
    version: int
    failure_code: str | None


class AppBuildResponse(BaseModel):
    id: uuid.UUID
    workspace_snapshot_id: uuid.UUID
    dependency_resolution_id: uuid.UUID
    status: str
    version: int
    reconciliation_required: bool
    failure_code: str | None


def build_service(request: Request) -> BuildService:
    settings = get_settings()
    permits = PermitService(request.app.state.sessions)

    async def validate_permit(permit_id: str, action: str) -> None:
        claimed = await permits.claim(uuid.UUID(permit_id), actor_id="dependency-resolver")
        if claimed.binding.action != action:
            raise ValueError("permit action mismatch")
        await permits.consume(claimed.id, nonce=claimed.nonce)

    root = Path(settings.build_root)
    return BuildService(
        request.app.state.sessions,
        DockerDependencyMaterializer(
            root=root / "dependencies",
            image=settings.dependency_resolver_image,
            egress_proxy=settings.dependency_egress_proxy,
            permit_validator=validate_permit,
        ),
        DockerSandboxDriver(root=root / "sandbox", image=settings.sandbox_image),
    )


BuildServiceDep = Annotated[BuildService, Depends(build_service)]


@router.post(
    "/v1/workspace-snapshots/{snapshot_id}/dependency-resolutions",
    response_model=DependencyResolutionResponse,
    status_code=status.HTTP_202_ACCEPTED,
)
async def request_dependency_resolution(
    snapshot_id: uuid.UUID, payload: RequestDependenciesBody, builds: BuildServiceDep
) -> DependencyResolutionResponse:
    model = await builds.request_dependencies(
        RequestDependencyResolution(workspace_snapshot_id=snapshot_id, **payload.model_dump())
    )
    return DependencyResolutionResponse(
        id=model.id,
        workspace_snapshot_id=model.workspace_snapshot_id,
        status=model.status,
        version=model.version,
        failure_code=model.failure_code,
    )


@router.post(
    "/v1/workspace-snapshots/{snapshot_id}/builds",
    response_model=AppBuildResponse,
    status_code=status.HTTP_202_ACCEPTED,
)
async def request_app_build(
    snapshot_id: uuid.UUID, payload: RequestBuildBody, builds: BuildServiceDep
) -> AppBuildResponse:
    model = await builds.request_build(
        RequestAppBuild(workspace_snapshot_id=snapshot_id, **payload.model_dump())
    )
    return build_response(model)


@router.get("/v1/app-builds/{build_id}", response_model=AppBuildResponse)
async def get_app_build(build_id: uuid.UUID, builds: BuildServiceDep) -> AppBuildResponse:
    return build_response(await builds.get_build(build_id))


def build_response(model: Any) -> AppBuildResponse:
    return AppBuildResponse(
        id=model.id,
        workspace_snapshot_id=model.workspace_snapshot_id,
        dependency_resolution_id=model.dependency_resolution_id,
        status=model.status,
        version=model.version,
        reconciliation_required=model.reconciliation_required,
        failure_code=model.failure_code,
    )


@router.post("/v1/app-builds/{build_id}/reconcile", response_model=AppBuildResponse)
async def reconcile_app_build(build_id: uuid.UUID, builds: BuildServiceDep) -> AppBuildResponse:
    return build_response(await builds.reconcile_build(build_id))
