from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from pathlib import Path

import uvicorn
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles

from regent import __version__
from regent.api.baselines import router as baselines_router
from regent.api.goals import router as goals_router
from regent.api.governance import router as governance_router
from regent.api.observations import router as observations_router
from regent.api.side_effects import router as side_effects_router
from regent.api.tools import router as tools_router
from regent.api.works import router as works_router
from regent.config import get_settings
from regent.domain.errors import DomainError, ErrorCode
from regent.infrastructure.database import create_engine, create_session_factory
from regent.model import ModelConfigurationError, ModelOutputError


def create_app() -> FastAPI:
    settings = get_settings()

    @asynccontextmanager
    async def lifespan(app: FastAPI) -> AsyncIterator[None]:
        engine = create_engine(settings)
        app.state.sessions = create_session_factory(engine)
        yield
        await engine.dispose()

    app = FastAPI(
        title="Regent Core API",
        version=__version__,
        description="Reliable, governed goal execution core.",
        lifespan=lifespan,
    )

    @app.exception_handler(DomainError)
    async def domain_error_handler(_request: Request, error: DomainError) -> JSONResponse:
        status_code = 404 if error.code is ErrorCode.NOT_FOUND else 409
        return JSONResponse(
            status_code=status_code,
            content={"error": {"code": error.code.value, "message": error.message}},
        )

    @app.exception_handler(ModelConfigurationError)
    async def model_configuration_handler(
        _request: Request, error: ModelConfigurationError
    ) -> JSONResponse:
        return JSONResponse(
            status_code=503,
            content={"error": {"code": "MODEL_NOT_CONFIGURED", "message": str(error)}},
        )

    @app.exception_handler(ModelOutputError)
    async def model_output_handler(_request: Request, error: ModelOutputError) -> JSONResponse:
        return JSONResponse(
            status_code=502,
            content={"error": {"code": "MODEL_OUTPUT_INVALID", "message": str(error)}},
        )

    @app.get("/health/live", tags=["operations"])
    async def liveness() -> dict[str, str]:
        return {"status": "ok"}

    @app.get("/health/ready", tags=["operations"])
    async def readiness() -> dict[str, str]:
        return {"status": "ok", "environment": settings.environment}

    console_path = Path("/app/apps/regent-console")
    if console_path.exists():
        app.mount("/console", StaticFiles(directory=console_path, html=True), name="console")

    @app.get("/", include_in_schema=False)
    async def root() -> RedirectResponse:
        return RedirectResponse("/console/")

    app.include_router(goals_router)
    app.include_router(baselines_router)
    app.include_router(governance_router)
    app.include_router(works_router)
    app.include_router(tools_router)
    app.include_router(observations_router)
    app.include_router(side_effects_router)
    return app


app = create_app()


def run() -> None:
    uvicorn.run("regent.api.main:app", host="0.0.0.0", port=8000)
