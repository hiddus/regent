import json
from dataclasses import dataclass
from typing import Any, Protocol, TypeVar

import httpx
from pydantic import BaseModel, ValidationError

ResponseT = TypeVar("ResponseT", bound=BaseModel)


class ModelConfigurationError(RuntimeError):
    pass


class ModelOutputError(RuntimeError):
    pass


@dataclass(frozen=True, slots=True)
class ModelUsage:
    input_tokens: int
    output_tokens: int


@dataclass(frozen=True, slots=True)
class StructuredModelResponse[ResponseT: BaseModel]:
    output: ResponseT
    usage: ModelUsage
    model: str


class ModelProvider(Protocol):
    async def generate_structured(
        self,
        *,
        system_prompt: str,
        user_prompt: str,
        response_model: type[ResponseT],
    ) -> StructuredModelResponse[ResponseT]: ...


class OpenAICompatibleProvider:
    def __init__(
        self,
        *,
        base_url: str,
        api_key: str,
        model: str,
        timeout_seconds: float = 60,
        client: httpx.AsyncClient | None = None,
    ) -> None:
        if not base_url or not api_key or not model:
            raise ModelConfigurationError("base URL, API key and model are required")
        self._base_url = base_url.rstrip("/")
        self._api_key = api_key
        self._model = model
        self._timeout = timeout_seconds
        self._client = client

    async def generate_structured(
        self,
        *,
        system_prompt: str,
        user_prompt: str,
        response_model: type[ResponseT],
    ) -> StructuredModelResponse[ResponseT]:
        schema = json.dumps(response_model.model_json_schema(), ensure_ascii=False)
        schema_prompt = f"{system_prompt}\nRequired JSON Schema:\n{schema}"
        payload: dict[str, Any] = {
            "model": self._model,
            "messages": [
                {"role": "system", "content": schema_prompt},
                {"role": "user", "content": user_prompt},
            ],
            "response_format": {"type": "json_object"},
            "temperature": 0,
        }
        owns_client = self._client is None
        client = self._client or httpx.AsyncClient(timeout=self._timeout)
        try:
            response = await client.post(
                f"{self._base_url}/chat/completions",
                headers={"Authorization": f"Bearer {self._api_key}"},
                json=payload,
            )
            response.raise_for_status()
            body = response.json()
            content = body["choices"][0]["message"]["content"]
            try:
                if isinstance(content, str) and content.strip().startswith("```"):
                    lines = content.strip().splitlines()
                    content = "\n".join(lines[1:-1])
                output = response_model.model_validate_json(content)
            except ValidationError as exc:
                details = exc.errors(include_input=False, include_url=False)
                raise ModelOutputError(
                    f"model returned invalid structured output: {details}"
                ) from exc
            except ValueError as exc:
                raise ModelOutputError("model returned invalid JSON output") from exc
            usage = body.get("usage", {})
            return StructuredModelResponse(
                output=output,
                usage=ModelUsage(
                    input_tokens=int(usage.get("prompt_tokens", 0)),
                    output_tokens=int(usage.get("completion_tokens", 0)),
                ),
                model=str(body.get("model", self._model)),
            )
        except (KeyError, IndexError, TypeError) as exc:
            raise ModelOutputError("model response envelope is invalid") from exc
        finally:
            if owns_client:
                await client.aclose()
