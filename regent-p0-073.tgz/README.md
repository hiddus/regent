# Regent 文档索引

## 唯一有效基线

后续产品、设计和编码工作默认只读取以下文档：

1. [Regent-PRD.md](./Regent-PRD.md) — 产品范围、状态语义、P0 验收与完成定义；
2. [Regent-Plan.md](./Regent-Plan.md) — 实现顺序、状态与 Permit 契约、编码门禁；
3. [Regent-Measurement-Decision-Framework.md](./Regent-Measurement-Decision-Framework.md) — 实验、指标、SLO 和产品转向门槛。

三份文档发生冲突时，产品范围与语义以 PRD 为准，实现细节以 Plan 为准，实验口径与决策门槛以 Measurement Framework 为准。冲突必须通过 DecisionRecord 或 ADR 解决，不能由编码实现自行选择。

## 历史文档

历史版本保存在 [docs/archive](./docs/archive/README.md)，仅用于设计追溯，不得作为当前编码输入或验收依据。
