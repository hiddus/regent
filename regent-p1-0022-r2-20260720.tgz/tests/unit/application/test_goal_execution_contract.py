from pathlib import Path

from regent.api.main import create_app
from regent.infrastructure.models import AppPreviewReleaseModel, OutboxEventModel
from sqlalchemy.dialects import postgresql
from sqlalchemy.schema import CreateTable


def test_start_goal_route_and_worker_handler_are_registered() -> None:
    paths = set(create_app().openapi()["paths"])
    worker = Path("core/src/regent/worker/main.py").read_text(encoding="utf-8")
    assert "/v1/goals/{goal_id}/start" in paths
    assert '"GoalExecutionRequested": handle_goal_execution' in worker
    assert '"GoalSpecFrozen": log_state_change' in worker


def test_confirmation_message_carries_frozen_version_token() -> None:
    source = Path("core/src/regent/application/app_project_service.py").read_text(
        encoding="utf-8"
    )
    assert '"goal_spec_hash": spec.content_hash' in source
    assert '"goal_spec_version": spec.version' in source


def test_outbox_dead_letter_and_preview_failure_summary_are_persistent() -> None:
    outbox_ddl = str(
        CreateTable(OutboxEventModel.__table__).compile(dialect=postgresql.dialect())
    )
    preview_ddl = str(
        CreateTable(AppPreviewReleaseModel.__table__).compile(dialect=postgresql.dialect())
    )
    assert "DEAD_LETTER" in outbox_ddl
    assert "failure_summary" in preview_ddl


def test_console_starts_goal_and_polls_persistent_progress() -> None:
    console = Path("apps/regent-console/index.html").read_text(encoding="utf-8")
    assert "`/v1/goals/${goalId}/start`" in console
    assert "execution_stage" in console
    assert "await refresh()" in console
    assert "},3000)" in console
